import React , { useEffect, useState } from 'react';
// Material UI Stuffs
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import IconButton from '@material-ui/core/IconButton';
import BookmarkBorderIcon from '@material-ui/icons/BookmarkBorder';


import Title from './Title';
import auth from './../../Services/authService';
import http from './../../Services/httpService';
import { apiUrl } from './../../config.json';
const apiUnbookmark = apiUrl + "/user/unbookmarked";
const URL = "http://localhost:3001/user/getBookmarkedList";

  function preventDefault(event) {
    event.preventDefault();
  }

  const useStyles = makeStyles((theme) => ({
    seeMore: {
      marginTop: theme.spacing(3),
    },
  }));

  export default function BookmarkedList() {

    const classes = useStyles();
    // datas can change 
    const [words, setWords] = useState([
    ]);

    useEffect(() => {
      http.get(URL, {})
      .then(({data}) => {
        let result = data.filter(function(data){
          return data.userId === auth.getCurrentUser()._id;
        });
        setWords(result);
      })
    }, [])

    async function unbookmarkedWord(word){
      const {data:{token:jwt}} = await http.post(apiUnbookmark, {word});
    }
    const handleClick = (event, word) => {
      event.preventDefault();
      console.log(word);
      unbookmarkedWord(word);
    }
  
    return (
      <React.Fragment>
        <Title>Bookmarked Words</Title>
        <Table size="small">
          <TableHead>
            <TableRow>
              {/* <TableCell>Date</TableCell> */}
              <TableCell>Word</TableCell>
              <TableCell>Type</TableCell>
              <TableCell align="right">Definition</TableCell>
              <TableCell>Unbookmarked</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {words.map((word, index) => (
              <TableRow key={index}>
                <TableCell>{word.word}</TableCell>
                <TableCell>{word.type}</TableCell>
                <TableCell align="right">{word.definition}</TableCell>
                <TableCell>
                <IconButton aria-label="bookmark" onClick ={(e)=>{handleClick(e,word.word)}}>
                  <BookmarkBorderIcon />
                </IconButton>
                  
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className={classes.seeMore}>
          <Link color="primary" href="#" onClick={preventDefault}>
            See more words
          </Link>
        </div>
      </React.Fragment>
    );
  }