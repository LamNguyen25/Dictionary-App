import React, { Component } from 'react'
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import ListSubheader from '@material-ui/core/ListSubheader';
import DashboardIcon from '@material-ui/icons/Dashboard';
import PeopleIcon from '@material-ui/icons/People';
import BarChartIcon from '@material-ui/icons/BarChart';
import AssignmentIcon from '@material-ui/icons/Assignment';
import AccountCircleIcon from '@material-ui/icons/AccountCircle';
import FormatListBulletedIcon from '@material-ui/icons/FormatListBulleted';
import BookmarkIcon from '@material-ui/icons/Bookmark';
import {Link} from 'react-router-dom';

export const mainListItems = (
    <div>
        <ListItem button>
            <ListItemIcon>
                <DashboardIcon />
            </ListItemIcon>
            <ListItemText primary="Dashboard" />
        </ListItem>
        <ListItem button component={Link} to ="/taskList">
            <ListItemIcon>
                <FormatListBulletedIcon />
            </ListItemIcon>
            <ListItemText primary="Task List" />
        </ListItem>
        <ListItem button>
            <ListItemIcon>
                <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary="Friends" />
        </ListItem>
        <ListItem button component={Link} to="/bookmarkedList">
            <ListItemIcon>
                <BookmarkIcon />
            </ListItemIcon>
            <ListItemText primary="Bookmark" />
        </ListItem>
        
      
    </div>
);

export const secondaryListItems = (
    <div>
      <ListSubheader inset>Sign off</ListSubheader>
      <ListItem button component={Link} to ="/logout">
        <ListItemIcon>
          <AccountCircleIcon />
        </ListItemIcon>
        <ListItemText primary="Log out" />
      </ListItem>
    </div>
  );