import React , { useEffect, useState } from 'react';
import clsx from 'clsx';
// Material UI Stuffs
import Link from '@material-ui/core/Link';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import Favorite from '@material-ui/icons/Favorite';
import FavoriteBorder from '@material-ui/icons/FavoriteBorder';
import IconButton from '@material-ui/core/IconButton';
import DeleteIcon from '@material-ui/icons/Delete';
import BookmarkIcon from '@material-ui/icons/Bookmark';

import Title from './Title';
import auth from './../../Services/authService';
import http from './../../Services/httpService';
import { apiUrl } from './../../config.json';
const apibookmark = apiUrl + "/user/bookmark";
const apiDelete = apiUrl + "/user/delete";
const URL = "http://localhost:3001/user/getWordList";


  function preventDefault(event) {
    event.preventDefault();
  }

  const useStyles = makeStyles((theme) => ({
    seeMore: {
      marginTop: theme.spacing(3),
    },
  }));

  export default function Orders() {

    const classes = useStyles();
    // datas can change 
    const [words, setWords] = useState([
    ]);

    const [inputValue, setInput] = useState("");

    useEffect(() => {
      //console.log(auth.getCurrentUser());
      http.get(URL, {})
      .then(({data}) => {
        console.log('from use effect', inputValue);
        let result = data.filter(function(data){
          return data.userId === auth.getCurrentUser()._id && data.word.toLowerCase().includes(inputValue);
        });
        setWords(result);

      })
    }, [])

    async function bookmarkWord(word){
      const {data:{token:jwt}} = await http.post(apibookmark, {word});
    }

    const handleBookmark = (event, word) => {
      event.preventDefault();
      console.log(word);
      bookmarkWord(word);
    }

    async function deleteWord(word){
      const {data:{token:jwt}} = await http.post(apiDelete, {word});
    }

    const handleDelete = (event, word) => {
      event.preventDefault();
      console.log(word);
      deleteWord(word);
    }
    
    const filteredWord = words.filter(data => {
        return data.word.toLowerCase().includes(inputValue.toLowerCase());
    });

    const wordFilterOnChange = (event) => {
     console.log("hi from onChange", event.target.value);
      setInput(event.target.value);
    }
    return (
      <React.Fragment>
        <Title>List of Words</Title>
        <TextField id="outlined-basic" label="Search by Word" variant="outlined" value={inputValue} onChange={wordFilterOnChange}/>
        <Table size="small">
          <TableHead>
            <TableRow>
              {/* <TableCell>Date</TableCell> */}
              <TableCell>Word</TableCell>
              <TableCell>Type</TableCell>
              <TableCell align="right">Definition</TableCell>
              <TableCell>Bookmark</TableCell>
            </TableRow>
          </TableHead>
          <TableBody >
            {filteredWord.map((word, index) => (
              <TableRow key={index}>
                <TableCell>{word.word}</TableCell>
                <TableCell>{word.type}</TableCell>
                <TableCell align="right">{word.definition}</TableCell>
                <TableCell>
                <IconButton aria-label="bookmark" onClick ={(e)=>{handleBookmark(e,word.word)}}>
                  <BookmarkIcon />
                </IconButton>

                {/* <FormControlLabel
                  control={<Checkbox icon={<FavoriteBorder />} checkedIcon={<Favorite />} name="checkedWord"/>}
                  label=""
                  onClick ={(e)=>{handleClick(e,word.word)}}
                 /> */}
                  {/* <ListItem button 
                    onClick ={(e)=>{handleClick(e,word._id)}}
                  >
                    <ListItemIcon>
                        <FavoriteOutlinedIcon/>
                    </ListItemIcon>
                    <ListItemText primary="" />
                  </ListItem> */}
                </TableCell>
                <TableCell>
                <IconButton aria-label="delete" onClick ={(e)=>{handleDelete(e,word.word)}}>
                  <DeleteIcon />
                </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
        <div className={classes.seeMore}>
          <Link color="primary" href="#" onClick={preventDefault}>
            See more words
          </Link>
        </div>
        
      </React.Fragment>
    );
  }