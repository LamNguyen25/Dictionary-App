import React, { PureComponent } from 'react'
// UI Stuffs
import clsx from 'clsx';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import SpellcheckIcon from '@material-ui/icons/Spellcheck';
import Grid from '@material-ui/core/Grid';
import AppBar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
//import CircularProgress from '@material-ui/core/CircularProgress';
import auth from './../../Services/authService';
import http from './../../Services/httpService';
import { apiUrl } from './../../config.json';
const apiAddNew = apiUrl + "/user/addNewWord";
const typeList = [
    {
        id: '1',
        value: 'Noun',
    },
    {
        id: '2',
        value: 'Pronoun',
    },
    {
        id: '3',
        value: 'Verb',
    },
    {
        id: '4',
        value: 'Adjective',
    },
    {
        id: '5',
        value: 'Adverb',
    },
    {
        id: '6',
        value: 'Preposition',
    },
    {
        id: '7',
        value: 'Conjunction',
    },
];

const useStyles = makeStyles(theme => ({
    root: {
        display: 'flex',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'], {
          easing: theme.transitions.easing.sharp,
          duration: theme.transitions.duration.leavingScreen,
        }),
    },
    toolbar: {
        paddingRight: 24, // keep right padding when drawer closed
    },
    typography: {
        userNextVariants: true,
      },
      form: {
        '& .MuiTextField-root': {
            margin: theme.spacing(1),
            width: '25ch',
          },
      },
      image: {
        margin: '20px auto 20px auto'
      },
      title: {
        flexGrow: 1,
      },
      pageTitle: {
        margin: '10px auto 10px auto'
      },
      textField: {
        margin: '10px auto 10px auto'
      },
      button: {
        marginTop: 20,
        position: 'relative'
      },
      customError: {
        color: 'red',
        fontSize: '0.8rem',
        marginTop: 10
      },
      progress: {
        position: 'absolute'
      }
  }));


export default function AddTask() {
    const classes = useStyles();
    //const [value, setValue] = React.useState('Controlled');
    const [values, setValues] = React.useState({
        userId: '',
        word: '',
        type: '',
        definition: '',
        isBookmarked: false,
      });
    
    const isEmpty = (string) => {
    
        if (string.trim() === '') return true;
        else return false;
    };
    async function addNewWord(userId, word, type, definition, isBookmarked) {
        let errors = {};
        if(isEmpty(word)){
            errors.newWord = 'You need to enter a new word';
            return errors;
        } else if(isEmpty(definition)) {
            errors.definition= 'Definition cannot be empty';
            return errors;
        }
        console.log("I'm here in the addNewWord");
        const {data:{token:jwt}} = await http.post(apiAddNew, {userId, word, type, definition, isBookmarked});
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        console.log(values);
        let userId = auth.getCurrentUser()._id;
        let isBookmarked = false;
        addNewWord(userId, values.word, values.type, values.definition, isBookmarked)
            .then(() => {
                window.location = "/dashboard";
            })
            .catch((err) => {
                if (err.response && err.response.status === 400) {
                    //Server Response
                    const errorMsg = err.response.data;
                    console.log(errorMsg);
                }
            })

    };
    const handleChange = prop => event => {
        setValues({ ...values, [prop]: event.target.value });
    };

    return (
        <div className={classes.root}>       
            <AppBar position="absolute" className={clsx(classes.appBar)}>
                <Toolbar className={classes.toolbar}>
                    <Typography component="h1" variant="h6" color="inherit" noWrap className={classes.title}>
                        Add a New Vocabulary
                    </Typography>
                </Toolbar>
            </AppBar>
        <Grid container className={classes.form}>
            
            <Grid item sm/>
            <Grid item sm>
                <SpellcheckIcon className={classes.image} />
                {/* <Typography variant="h4" className={classes.pageTitle}>Add a New Word</Typography> */}
                <form noValidate autoComplete="off">
                    <TextField
                        id="standard-textarea"
                        label="Word"
                        value={values.word}
                        placeholder="Placeholder"
                        multiline
                        onChange={handleChange('word')}
                    />
                    <TextField
                        select
                        label="Select"
                        value={values.type}
                        onChange={handleChange('type')}
                        helperText="Please select your type"
                    >
                    {typeList.map(option => (
                        <MenuItem key={option.value} value={option.value} >
                        {option.value}
                        </MenuItem>
                    ))}
                    </TextField>

                    <TextField className={classes.margin}
                        label="Definition"
                        name="definition"
                        value={values.definition}
                        onChange={handleChange('definition')}
                        >
                    </TextField>
                    <br/>
                    <Button 
                        type="submit" 
                        variant="outlined" 
                        color="primary"
                        className={classes.button}
                        onClick={handleSubmit} 
                    >
                    Add
                    </Button>
                </form>
            </Grid>
            <Grid item sm/>
        </Grid>
        </div>
    )
 }

