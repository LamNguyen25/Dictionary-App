import React, { PureComponent } from 'react'
import auth from '../Services/authService';
import Navbar from './../components/NavBar';
export default class logout extends PureComponent {

    render() {
        auth.logout()
        window.location = "/";
        return (
            <div>
            <Navbar/>
                
            </div>
        )
    }
}
