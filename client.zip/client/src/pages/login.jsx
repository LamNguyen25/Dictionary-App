import React from 'react';
import './login.css';
import { Formik } from "formik";
import Navbar from './../components/NavBar';
//import  EmailValidator from "email-validator";
import auth from '../Services/authService';
import * as Yup from "yup";
// import Joi from '@hapi/joi';
import { MDBContainer, MDBRow, MDBCol, MDBCard, MDBCardBody, MDBInput, MDBBtn, MDBIcon, MDBModalFooter } from 'mdbreact';
import { Redirect } from 'react-router-dom';

const ValidationSchema = Yup.object().shape({
    email: Yup.string()
              .email()
              .required("Required"),
    password: Yup.string()
              .required("No password provided.")
              .min(8, "Password is too short - should be 8 chars minimum.")
              .matches(/(?=.*[0-9])/, "Password must contain a number.")
})

class login extends React.PureComponent{
    constructor() {
        super();
        this.state = {
          email: '',
          password: '',
          error: {}
        }
      }
      
    handleSubmit = (event) => {
         event.preventDefault();
        // connect to loginUser in userActions
        auth.login(this.state.email, this.state.password)
        .then(() => {
            window.location = "/dashboard";
        })
        .catch((err) => {
            if (err.response && err.response.status === 400) {
                //Server Response
                const errorMsg = err.response.data;
                console.log(errorMsg);
              }
        })

      };
    // // Set the value to its correspondent state
    handleChange = (event) => {
        this.setState({
        [event.target.name]: event.target.value
        })
    };
    render (){
        if (auth.getCurrentUser()) return <Redirect to="/dashboard"/>;
    return (
        
        <MDBContainer container>
            <Navbar/>
            <MDBRow>
            <MDBCol />
            <MDBCol size="6">
                <MDBCard>
                <MDBCardBody className="mx-4">
                    <div className="text-center">
                    <h3 className="dark-grey-text mb-5">
                        <strong>Sign in</strong>
                    </h3>
                    </div>
                    <Formik
                        initialValues={{
                            email: "",
                            password: "",
                            error: ''
                        }}
                        validationSchema={ValidationSchema}
                        onSubmit={(values, { setSubmitting }) => {
                            setTimeout(() => {
                            console.log("Logging in", values);
                            setSubmitting(false);
                            }, 500);
                        }}

                    >
                    {({
                        
                        touched,
                        errors,
                        isSubmitting,
                       //this.handleSubmit,
                        //handleChange

                        //handleChange
                    }) => (
                        <form noValidate>
                                <MDBInput
                                label="Your email"
                                group
                                type="email"
                                validate
                                error="wrong"
                                success="right"
                                name="email"
                                onChange = {this.handleChange}
                                //value={this.state.email}
                                // check the touched property, 
                                // to see whether or not the user has interacted with the email input before showing an error message
                                className={errors.email && touched.email && "error"}
                                />
                            
                                {errors.email && touched.email && ( // if there are errors, we will display them to the user
                                <div className="input-feedback">{errors.email}</div>
                                )}

                                <MDBInput
                                label="Your password"
                                group
                                type="password"
                                validate
                                containerClass="mb-0"
                                required
                                name="password"
                                //value={this.state.password}
                                onChange = {this.handleChange}
                                className={errors.password && touched.password && "error"}
                                />
                                {errors.password && touched.password && (
                                <div className="input-feedback">{errors.password}</div>
                                )}

                                <div className="custom-control custom-checkbox mb-3">
                                    <input type="checkbox" className="custom-control-input" id="customCheck1"/>
                                    <label className="custom-control-label" htmlFor="customCheck1">Remember password</label>
                                </div>
                                <p className="font-small blue-text d-flex justify-content-end pb-3">
                                Forgot
                                <a href="#!" className="blue-text ml-1">
                
                                    Password?
                                </a>
                                </p>
                                <div className="text-center mb-3">
                                <MDBBtn
                                    type="submit"
                                    gradient="orange"
                                    rounded
                                    className="btn-block z-depth-1a"
                                    onClick={this.handleSubmit} 
                                    disabled={isSubmitting}
                                >
                                    Sign in
                                </MDBBtn>
                                </div>
                        </form>
                 )}
           </Formik>
                    
                    <p className="font-small dark-grey-text text-right d-flex justify-content-center mb-3 pt-2">
    
                    or Sign in with:
                    </p>
                    <div className="row my-3 d-flex justify-content-center">
                    <MDBBtn
                        type="button"
                        color="white"
                        rounded
                        className="mr-md-3 z-depth-1a"
                    >
                        <MDBIcon fab icon="facebook-f" className="blue-text text-center" />
                    </MDBBtn>
                    <MDBBtn
                        type="button"
                        color="white"
                        rounded
                        className="mr-md-3 z-depth-1a"
                    >
                        <MDBIcon fab icon="twitter" className="blue-text" />
                    </MDBBtn>
                    <MDBBtn
                        type="button"
                        color="white"
                        rounded
                        className="z-depth-1a"
                    >
                        <MDBIcon fab icon="google-plus-g" className="blue-text" />
                    </MDBBtn>
                    </div>
                </MDBCardBody>
                <MDBModalFooter className="mx-5 pt-3 mb-1">
                    <p className="font-small grey-text d-flex justify-content-end">
                    Not a member?
                    <a href="#!" className="blue-text ml-1">
    
                        Sign Up
                    </a>
                    </p>
                </MDBModalFooter>
                </MDBCard>
            </MDBCol>
            <MDBCol/>
            </MDBRow>
        </MDBContainer>
        
    )
}
}
export default login;
