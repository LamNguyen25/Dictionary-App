import axios from "axios";
/*> This Class is for create HTTP services with a custome middleware
  => alert error if connection is Wrong!
*/
axios.interceptors.response.use(null, error => {
    const expectedError = 
        error.response &&
        error.response.status >= 400 &&
        error.response.status < 500;

        // If unexpected error do something with it
        if(!expectedError) {
            console.log(error);
            alert("An unexpected HTTP error occurred.");
        }
        // return the RESPONSE error from server (including any error that server throw)
    return Promise.reject(error);
});

// Attach JWT to ALL the call using this axios !!
// This is only to demonstrate how we can use x-auth-token (Not needed here)
function setJwt(jwt) {
  // axios.defaults.headers.common["x-auth-token"] = jwt;
  axios.defaults.headers.common = {'Authorization': `Bearer ${jwt}`}
}

export default {
    get : axios.get,
    post: axios.post,
    put : axios.put,
    delete: axios.delete,
    setJwt
  };