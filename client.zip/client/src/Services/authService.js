import jwtDecode from "jwt-decode";
import http from "./httpService";
import { apiUrl } from "../config.json";


const apiLogin  = apiUrl + "/login";
const apiSignup  = apiUrl + "/user/test-account";
const apiDashBoard = apiUrl + "/dashboard";
const apiAddNew = apiUrl + "/user/addNewWord";
const apiGetList = apiUrl + "/user/getWordList";
const tokenKey  = "token"; // key-value name

// Attach JWT to ALL the call using this axios!!!
// This is only to demonstrate how we can use x-auth-token (Not needed here)
// http.setJwt(getJwt());
//const LOGINAPI = "http://localhost:3001/login/";

// export async function fetchCurrentUserData(url) {
//     try {
//         const jwt = localStorage.getItem(tokenKey);
//         const data = await http.post(apiUrl + url, jwtDecode(jwt));
//         return data;
//     } catch (ex) {
//         return;
//     }
// }

export async function login(email, password) {
    
    //const data = await http.post(apiLogin, {email, password });
    const {data:{token:jwt}} = await http.post(apiLogin, {email, password });

    localStorage.setItem(tokenKey, jwt);
    //console.log(jwt);
}

export async function signup(firstName, lastName, email, password, confirmPassword) {
    const {data:{token:jwt}} = await http.post(apiSignup, {firstName, lastName, email, password, confirmPassword });
    
    //localStorage.setItem(tokenKey, jwt);
    //console.log(jwt);
}

export function loginWithJwt(jwt) {
    localStorage.setItem(tokenKey, jwt);
}

export function logout() {
    localStorage.removeItem(tokenKey);
}

// Get current user by decoding JWT in Local Storage
export function getCurrentUser() {
    // Always try to catch this because invalid token make the app crash
    // localStorage.getItem('token')    // get the token header
    try {
        const jwt = localStorage.getItem(tokenKey);
        return jwtDecode(jwt);
    } catch (ex) {
        return null;
    }
}

export function getJwt() {
    return localStorage.getItem(tokenKey);
}


export default {
    login,
    loginWithJwt,
    logout,
    getCurrentUser,
    getJwt,
    //fetchCurrentUserData,
    signup,
};

