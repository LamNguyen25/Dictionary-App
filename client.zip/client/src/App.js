import React from 'react';
import './App.css';

// MUI stuffs
//import MuiThemeProvider from '@material-ui/core/styles/MuiThemeProvider';
import {ThemeProvider as MuiThemeProvider} from '@material-ui/core/styles';
import createMuiTheme from '@material-ui/core/styles/createMuiTheme';
import jwtDecode from 'jwt-decode';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
// Pages
import Navbar from './components/NavBar';
import Dashboard from './pages/Dashboard';
import login from './pages/login';
import signup from './pages/signup';

import logout from './pages/logout';
import taskList from './pages/Home/TaskList';
import bookmarkedList from './pages/Home/BookmarkedList';
import addTask from './pages/Home/AddTask';
import ProtectedRoute from './ProtectedRoute/ProtectedRoute';
const theme = createMuiTheme({
  palette: {
    primary: {
      light: '#3ECCBB',
      main: '#279185',
      dark: '#1A6158',
      contrastText: '#fff'
    },
    secondary: {
      light: '#ffb5a7',
      main: '#e07a5f',
      dark: '#b22a00',
      contrastText: '#fff'
    }
  },
}
)
// let authenticated;
// // Get the token from local storage
// const token = localStorage.FBIdToken;
//  // npm install --save jwt-decode (decode Json tokenId)
//  if(token) {
//    const decodedToken = jwtDecode(token);
//    if(decodedToken.exp * 1000 < Date.now()) { // Token is expired
//       window.location.href = '/login'         // go back to login page
//       authenticated = false;
//    } else {
//      authenticated = true;
//    }
//  }

function App() {
    return (
        <MuiThemeProvider theme={theme}>
        <Router>
        {/* <Navbar/> */}
          <div className="container">
            <Switch>
              <Route exact path="/" component={login}/>
              <Route path="/signup" component={signup}/>
              <Route path="/logout" component={logout}/>
              <Route path="/TaskList" component={taskList} />
              <Route path="/AddTask" component={addTask} />
              <Route path="/bookmarkedList" component={bookmarkedList} />
              <ProtectedRoute path="/dashboard" render={() => <Dashboard/>} />
            </Switch>
          </div>
        </Router>
    </MuiThemeProvider>
    )
}
export default App;