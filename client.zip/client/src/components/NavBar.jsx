import React, { Component } from 'react'
import {Link} from 'react-router-dom';
// MUI stuff
import Appbar from '@material-ui/core/AppBar';
import Toolbar from '@material-ui/core/Toolbar';
import Button from '@material-ui/core/Button';
 class Navbar extends Component {
    render() {
        return (
            <div>
                <Appbar>
                    <Toolbar className="nav-container">
                        <Button color="inherit" component={Link} to ="/">Login</Button>
                        <Button color="inherit" component={Link} to ="/dashboard">Home</Button>
                        <Button color="inherit" component={Link} to ="/signup">Signup</Button>
                        <Button color="inherit" component={Link} to ="/logout">Logout</Button>
                    </Toolbar>
                </Appbar>
            </div>
        )
    }
}
export default Navbar